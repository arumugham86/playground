package com.employee.load;

import org.jsmart.zerocode.core.domain.LoadWith;
import org.jsmart.zerocode.core.domain.TestMapping;
import org.jsmart.zerocode.core.runner.parallel.ZeroCodeLoadRunner;
import org.junit.runner.RunWith;

import com.employee.test.api.ApiTest;

//which test is each spawned user execute
@TestMapping(testClass = ApiTest.class, testMethod = "createUser")
//how many users are we going to spawn
@LoadWith("load_config.properties")
//run it with zero code load runner
@RunWith(ZeroCodeLoadRunner.class)
public class LoadTest {
}
