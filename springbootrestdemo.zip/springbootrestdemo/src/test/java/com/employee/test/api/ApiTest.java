package com.employee.test.api;

import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(ZeroCodeUnitRunner.class)
@TargetEnv("load_config.properties")
public class ApiTest {

	private RestTemplate restTemplate = new RestTemplate();

	@Test
	public void createUser() {
		ResponseEntity<String> responseDtoResponse = restTemplate.getForEntity("http://localhost:8080/employees/", String.class);

		assertThat(responseDtoResponse.getStatusCode().value()).isEqualTo(200);
	}
}
