package com.employee.test.api;

import static org.assertj.core.api.Assertions.assertThat;

import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.employee.rest.dao.EmployeeDAO;

@RunWith(ZeroCodeUnitRunner.class)
@TargetEnv("load_config.properties")
public class EmployeeDaoTest {

	EmployeeDAO dao = new EmployeeDAO();
	
	@Test
	public void getAllTest() {
		assertThat(dao.getAllEmployees().getEmployeeList().size()).isEqualTo(3);
	}
}
